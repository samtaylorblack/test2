--Begin Nerkh.lua By @MahDiRoO
do
 function run(msg, matches)
return [[ 
تعرفه ﴿*MaTaDoT*﴾
`1》ماهــــــــــیانـــــہ🌀`
_5000✔_
`2》سه ماهـــــــہ🌀`
_14000✔_
`3》برای هــــمیــشــــہ🌀`
_25000✔_
*☠پرداخت به دو صورت:*
_1.💲کارت به کارت🎗_
_2.💲شارژ با پرداخت بیشتر🎗_
*〰〰〰〰〰〰〰〰*
`برای خرید به ایدی:`
@MahDiRoO
]]
end
return {
patterns = {
"^[!/#][Nn]erkh$",
"^[Nn]erkh$",
"^jkmjnjnj$"
},
run = run
}
end
--End Nerkh.lua--
