# [вℓα¢к ™](https://telegram.me/GODILOVEYOUME2)


* * *


# Installation

```sh
# Let's install the bot.
cd $HOME
git clone https://github.com/blacknewn/blackmod.git
cd blackmod
chmod +x matador.sh
./beybal.sh install
./beybal.sh 
# Enter a phone number & confirmation code.
```
### One command
To install everything in one command, use:
```sh
cd $HOME && git clone https://github.com/blacknewn/blackmod.git && cd blackmod && chmod +x beybal.sh && ./beybal.sh install && ./beybal.sh
```

* * *

### launch Bot

```
killall -9 bash
cd blackmod && killall screen && screen ./beybal.sh
```

* * *


### auto launch 
```
bi pv :)🔮
@GODILOVEYOUME2
```

* * *


### Sudo

Open ./bot/bot.lua and add your ID to the "sudo_users" section in the following format:
```
    sudo_users = {
    202024626,
    0,
    YourID
  }
